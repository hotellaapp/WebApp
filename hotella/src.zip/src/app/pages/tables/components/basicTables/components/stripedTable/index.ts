export * from './stripedTable.component';
