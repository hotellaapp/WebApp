import { Component } from '@angular/core';

@Component({
  selector: 'select-inputs',
  styleUrls: ['./selectInput.scss'],
  templateUrl: './selectInputs.html'
})
export class SelectInputs {
  constructor() { }
}
