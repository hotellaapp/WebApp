import {Component} from '@angular/core';

@Component({
  selector: 'horizontal-form',
  templateUrl: './horizontalForm.html',
})
export class HorizontalForm {

  constructor() {
  }

  isRemember: boolean = false;
}
