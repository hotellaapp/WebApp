export interface Informacao {

    idInformacao: number,
    nome: string,                                                                                                                                                                                                                                  
    descricao: string,
    caminho_imagem: string,
    link: string,
    longitude: string,
    latitude: string,
    morada: string
  }