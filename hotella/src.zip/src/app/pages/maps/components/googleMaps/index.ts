export * from './googleMaps.component';
