export interface Codigo {

    token: string
  }