import {Component} from '@angular/core';
import { ButtonsService } from './buttons.service';

@Component({
  selector: 'buttons',
  templateUrl: './buttons.html',
  styleUrls: ['./buttons.scss']
})
export class Buttons {

  constructor(protected service: ButtonsService) {
  }

  public gerar(idReserva:string) {
    this.service.getCodigo(idReserva).subscribe();
  }

  public cancelar(title:string) {
    alert(title);
  }
}
