import {Component} from '@angular/core';


@Component({
  selector: 'raised-buttons',
  templateUrl: './raisedButtons.html',
})
export class RaisedButtons {

  constructor() {
  }
}
