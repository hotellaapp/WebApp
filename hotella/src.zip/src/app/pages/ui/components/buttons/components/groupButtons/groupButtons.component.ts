import {Component} from '@angular/core';

@Component({
  selector: 'group-buttons',
  templateUrl: './groupButtons.html',
})
export class GroupButtons {

  constructor() {
  }
}
