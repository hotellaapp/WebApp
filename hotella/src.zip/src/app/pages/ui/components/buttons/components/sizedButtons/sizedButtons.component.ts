import {Component} from '@angular/core';


@Component({
  selector: 'sized-buttons',
  templateUrl: './sizedButtons.html',
})
export class SizedButtons {

  constructor() {
  }
}
