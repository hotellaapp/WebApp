import { Component } from '@angular/core';


@Component({
  selector: 'disabled-buttons',
  templateUrl: './disabledButtons.html',
})
export class DisabledButtons {

  constructor() {
  }
}
