export * from './slim.component';
