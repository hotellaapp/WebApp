import {Component,OnInit} from '@angular/core';
import {FormGroup, AbstractControl, FormBuilder, Validators} from '@angular/forms';
import {Router, ActivatedRoute} from '@angular/router';
import { Http } from '@angular/http';
import { LoginService } from './login.service';
import { User } from '../user';


@Component({
  selector: 'login',
  templateUrl: './login.html',
  styleUrls: ['./login.scss']
})

export class Login implements OnInit{

  public form:FormGroup;
  public email:AbstractControl;
  public password:AbstractControl;
  public submitted:boolean = false;
  public x;
  sub: any;
  user: User;
  errorMessage: string = '';

  constructor(fb:FormBuilder,private loginService: LoginService,  private router: Router,private route: ActivatedRoute) {
    
    this.form = fb.group({
      'email': ['', Validators.compose([Validators.required, Validators.minLength(4)])],
      'password': ['', Validators.compose([Validators.required, Validators.minLength(4)])]
    });

    this.email = this.form.controls['email'];
    this.password = this.form.controls['password'];
  }

  ngOnInit(){
    this.sub = this.route.params.subscribe(params => {
      let id = Number.parseInt(params['id']);
      console.log('getting person with id: ', id);
      //this.loginService
        //.get(id)
        //.subscribe(p => this.user = p);
    });
}

  public onSubmit(values:Object):void {
    this.submitted = true;
    if (this.form.valid) {
      // your code goes here
      this.loginService.getAll(this.form.value['email']).subscribe(
        data => 
        {
          console.log(this.form.value['password'])
          if(data['password']== this.form.value['password'])
            this.router.navigateByUrl('pages/dashboard');
          else this.router.navigateByUrl('');
        },
        error => console.log(error)
      )

      
      console.log(this.x)

    }
    //Fazer verificação
    

    }

  }
  

