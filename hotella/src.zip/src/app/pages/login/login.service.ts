import {Injectable} from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { User } from '../user';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';


@Injectable()
export class LoginService {
    private baseUrl: string = 'https://hotella.herokuapp.com/api';

    constructor(private http : Http){

    }
    
  getAll(email): Observable<User[]>{
   // let people = this.http
     // .get(`${this.baseUrl}/utilizadores/all`).subscribe(val => console.log(val.text()))
      //.map(mapPersons)
      //.catch(handleError);
      //this.people$.subscribe(val => console.log(val));
      //this.http.get(`${this.baseUrl}/utilizadores/all`).subscribe(val => console.log(val.text()))
      return this.http.get(`${this.baseUrl}/utilizadores/=`+email).map((res:Response) =>res.json()).catch(handleError);
  }

}

// this could also be a private method of the component class
function handleError (error: any) {
  // log error
  // could be something more sofisticated
  let errorMsg = error.message || `Yikes! There was a problem with our hyperdrive device and we couldn't retrieve your data!`
  console.error(errorMsg);

  // throw an application level error
  return Observable.throw(errorMsg);
}