export const PAGES_MENU = [
  {
    path: 'pages',
    children: [
      {
        path: 'dashboard',
        data: {
          menu: {
            title: 'general.menu.dashboard',
            icon: 'ion-android-home',
            selected: false,
            expanded: false,
            order: 0
          }
        }
      },
      {
        path: 'servicos',
        data: {
          menu: {
            title: 'Serviços',
            icon: 'ion-stats-bars',
            selected: false,
            expanded: false,
            order: 200,
          }
        },
      },
      {
        path: 'checkinout',
        data: {
          menu: {
            title: 'Check in/Check out',
            icon: 'ion-android-laptop',
            selected: false,
            expanded: false,
            order: 300,
          }
        },
        
      },
      {
        path: 'informacoes',
        data: {
          menu: {
            title: 'Informações',
            icon: 'ion-compose',
            selected: false,
            expanded: false,
            order: 400,
          }
        },
       
      }, 
    ]
  
  }
];
